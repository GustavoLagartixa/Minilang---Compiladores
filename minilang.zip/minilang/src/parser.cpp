#include "parser.hpp"

namespace {
struct Frame { int sym; PNode* node; };

constexpr size_t kMaxErrors = 30;

// Tokens em que o parser retoma a análise depois de um erro (modo pânico).
bool isSync(int k) { return k == T_SEMICOLON || k == T_END || k == T_DOT || k == T_EOF; }

std::string expectedFor(const Grammar& g, int nt) {
    std::vector<int> a, b;  // a: produções não-vazias; b: produções vazias (tokens de FOLLOW)
    for (int t = 0; t < T_COUNT; t++) {
        int p = g.table[nt - T_COUNT][t];
        if (p < 0) continue;
        (g.prods[p].rhs.empty() ? b : a).push_back(t);
    }
    a.insert(a.end(), b.begin(), b.end());
    std::string s;
    size_t n = 0;
    for (int t : a) {
        if (n == 8) { s += ", ..."; break; }
        if (n) s += ", ";
        s += tokQuoted(t);
        n++;
    }
    return s;
}
}  // namespace

ParseResult parseTokens(const Grammar& g, const std::vector<Token>& toks) {
    ParseResult r;
    r.root = std::make_unique<PNode>();
    r.root->sym = N_PROGRAMA;

    std::vector<Frame> st;
    st.push_back({T_EOF, nullptr});
    st.push_back({N_PROGRAMA, r.root.get()});
    size_t pos = 0;

    auto fail = [&](const std::string& msg) {
        const Token& t = toks[pos];
        r.errors.push_back({t.line, t.col, false, msg});
    };

    auto recover = [&]() {
        // 1) descarta tokens até um ponto de sincronização
        while (!isSync(toks[pos].kind)) pos++;
        int cur = toks[pos].kind;
        // 2) desempilha até o topo poder tratar o token atual
        while (!st.empty()) {
            int top = st.back().sym;
            if (Grammar::isTerminal(top)) { if (top == cur) break; }
            else if (g.table[top - T_COUNT][cur] >= 0) break;
            st.pop_back();
        }
    };

    while (!st.empty()) {
        if (r.errors.size() >= kMaxErrors) {
            fail("muitos erros; análise interrompida");
            break;
        }
        Frame f = st.back();
        const Token& t = toks[pos];

        if (Grammar::isTerminal(f.sym)) {
            if (f.sym == t.kind) {
                if (f.node) f.node->tok = t;
                st.pop_back();
                if (t.kind != T_EOF) pos++;
                continue;
            }
            fail("esperado " + tokQuoted(f.sym) + ", encontrado " + describe(t));
            recover();
            continue;
        }

        int p = g.table[f.sym - T_COUNT][t.kind];
        if (p < 0) {
            fail("token inesperado " + describe(t) + "; esperado: " + expectedFor(g, f.sym));
            recover();
            continue;
        }
        st.pop_back();
        f.node->prod = p;
        const auto& rhs = g.prods[p].rhs;
        for (int s : rhs) {
            auto c = std::make_unique<PNode>();
            c->sym = s;
            f.node->ch.push_back(std::move(c));
        }
        for (size_t i = rhs.size(); i-- > 0;) st.push_back({rhs[i], f.node->ch[i].get()});
    }
    return r;
}
