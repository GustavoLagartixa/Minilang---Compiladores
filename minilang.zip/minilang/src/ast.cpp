#include "ast.hpp"
#include <functional>
#include <iostream>

namespace {
NodePtr mk(NK k, const Token& t, std::string text = "") {
    auto n = std::make_unique<Node>();
    n->kind = k; n->text = std::move(text); n->line = t.line; n->col = t.col;
    return n;
}
const PNode& C(const PNode& n, size_t i) { return *n.ch[i]; }

NodePtr buildBloco(const PNode& n);
NodePtr buildExpr(const PNode& n);
NodePtr buildStmt(const PNode& n);

// expr e expr_simples têm o mesmo formato: [operando, cauda(op, resto)] com cauda opcional.
// A gramática LL(1) é recursiva à direita (a-b-c = a-(b-c)); aqui a árvore é
// refeita com associatividade à ESQUERDA, que é a semântica correta.
NodePtr foldLeft(const PNode& n, const std::function<NodePtr(const PNode&)>& leaf) {
    std::vector<NodePtr> operands;
    std::vector<const Token*> ops;
    const PNode* cur = &n;
    for (;;) {
        operands.push_back(leaf(C(*cur, 0)));
        const PNode& tail = C(*cur, 1);
        if (tail.ch.empty()) break;
        ops.push_back(&C(tail, 0).tok);
        cur = &C(tail, 1);
    }
    NodePtr acc = std::move(operands[0]);
    for (size_t i = 0; i < ops.size(); i++) {
        auto b = mk(NK::BinOp, *ops[i], ops[i]->lexeme);
        b->kids.push_back(std::move(acc));
        b->kids.push_back(std::move(operands[i + 1]));
        acc = std::move(b);
    }
    return acc;
}

NodePtr buildFator(const PNode& n) {
    const Token& t = C(n, 0).tok;
    if (t.kind == T_ID) return mk(NK::Id, t, t.lexeme);
    auto num = mk(NK::Number, t, t.lexeme);
    num->value = t.value;
    return num;
}

NodePtr buildTermo(const PNode& n) {
    if (C(n, 0).sym == N_FATOR) return buildFator(C(n, 0));
    return buildExpr(C(n, 1));  // '(' expr ')'
}

NodePtr buildExprS(const PNode& n) { return foldLeft(n, buildTermo); }
NodePtr buildExpr(const PNode& n) { return foldLeft(n, buildExprS); }

NodePtr buildRel(const PNode& n) {
    const Token& op = C(C(n, 1), 0).tok;
    auto r = mk(NK::RelOp, op, op.lexeme);
    r->kids.push_back(buildExpr(C(n, 0)));
    r->kids.push_back(buildExpr(C(n, 2)));
    return r;
}

NodePtr buildCorpo(const PNode& n) {
    if (C(n, 0).sym == N_BLOCO) return buildBloco(C(n, 0));
    auto b = mk(NK::Block, C(n, 0).ch[0]->tok);  // comando único vira bloco
    b->kids.push_back(buildStmt(C(n, 0)));
    return b;
}

NodePtr buildStmt(const PNode& n) {  // n: comando_ne
    const Token& first = C(n, 0).tok;
    switch (n.prod) {
        case 7: {
            auto a = mk(NK::Assign, first, first.lexeme);
            a->kids.push_back(buildExpr(C(n, 2)));
            return a;
        }
        case 8: return mk(NK::Read, C(n, 2).tok, C(n, 2).tok.lexeme);
        case 9: {
            auto w = mk(NK::Write, first);
            w->kids.push_back(buildExpr(C(n, 2)));
            return w;
        }
        case 10: {
            auto i = mk(NK::If, first);
            i->kids.push_back(buildRel(C(n, 1)));
            i->kids.push_back(buildCorpo(C(n, 3)));
            const PNode& cp = C(n, 4);
            if (!cp.ch.empty()) i->kids.push_back(buildCorpo(C(cp, 1)));
            return i;
        }
        default: {  // 11: while
            auto w = mk(NK::While, first);
            w->kids.push_back(buildRel(C(n, 1)));
            w->kids.push_back(buildCorpo(C(n, 3)));
            return w;
        }
    }
}

NodePtr buildBloco(const PNode& n) {
    auto b = mk(NK::Block, C(n, 0).tok);
    const PNode* cmd = &C(C(n, 1), 0);       // linhas -> comando linhas'
    const PNode* rest = &C(C(n, 1), 1);
    for (;;) {
        if (!cmd->ch.empty()) b->kids.push_back(buildStmt(C(*cmd, 0)));
        if (rest->ch.empty()) break;          // linhas' -> ε
        cmd = &C(*rest, 1);                   // linhas' -> ';' comando linhas'
        rest = &C(*rest, 2);
    }
    return b;
}
}  // namespace

NodePtr buildAst(const PNode& root, SymbolTable& st) {
    const Token& id = C(root, 1).tok;
    auto p = mk(NK::Program, id, id.lexeme);
    p->kids.push_back(buildBloco(C(root, 3)));
    st.release(id.lexeme);  // o nome do programa não é variável
    return p;
}

void dumpAst(const Node& n, std::ostream& os, int depth) {
    static const char* names[] = {"Program", "Block", "Assign", "Read", "Write", "If", "While",
                                  "BinOp", "RelOp", "Id", "Number"};
    os << std::string(depth * 2, ' ') << names[(int)n.kind];
    if (n.kind == NK::Number) os << " " << n.value;
    else if (!n.text.empty()) os << " " << n.text;
    os << "  @" << n.line << ":" << n.col << "\n";
    for (auto& k : n.kids) dumpAst(*k, os, depth + 1);
}
