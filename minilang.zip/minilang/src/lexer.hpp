#pragma once
#include <string>
#include <vector>
#include "symtab.hpp"

enum Tok {
    T_PROGRAM, T_BEGIN, T_END, T_READ, T_WRITE, T_IF, T_THEN, T_ELSE, T_WHILE, T_DO, T_INT,
    T_ID, T_NUMBER,
    T_ASSIGN, T_PLUS, T_MINUS, T_TIMES, T_DIVIDE, T_EQ, T_LT, T_GT,
    T_LPAREN, T_RPAREN, T_LBRACE, T_RBRACE, T_SEMICOLON, T_COLON, T_COMMA, T_DOT,
    T_EOF,
    T_COUNT
};

struct Token {
    int kind = T_EOF;
    std::string lexeme;
    long value = 0;
    int line = 1, col = 1;
};

struct Diag {
    int line, col;
    bool lexical;
    std::string msg;
};

const char* tokName(int kind);          // "PROGRAM", "ID", ...
std::string tokQuoted(int kind);        // "'begin'", "identificador", ...
std::string describe(const Token& t);   // "identificador 'x'", "número 42", ...

// Varre o código-fonte inteiro. Erros léxicos vão para `errs`; a varredura continua.
std::vector<Token> lex(const std::string& src, SymbolTable& st, std::vector<Diag>& errs);
