// Gramática LL(1) da MiniLang (já sem recursão à esquerda e fatorada),
// com cálculo de FIRST/FOLLOW e construção da tabela de parsing.
#pragma once
#include <iosfwd>
#include <set>
#include <string>
#include <vector>
#include "lexer.hpp"

enum NT {
    N_PROGRAMA = T_COUNT, N_BLOCO, N_LINHAS, N_LINHAS_P, N_COMANDO, N_COMANDO_NE, N_CORPO,
    N_COND_P, N_RELACIONAL, N_EXPR, N_EXPR_P, N_EXPR_S, N_EXPR_S_P, N_TERMO, N_FATOR, N_RELOP,
    N_END
};
constexpr int NUM_NT = N_END - T_COUNT;

struct Prod {
    int lhs;
    std::vector<int> rhs;  // vazio = epsilon
};

class Grammar {
public:
    Grammar();

    std::vector<Prod> prods;
    std::vector<bool> nullable;                // por índice de não-terminal
    std::vector<std::set<int>> first, follow;  // por índice de não-terminal
    std::vector<std::vector<int>> table;       // [nt][token] -> produção, ou -1
    std::vector<std::string> resolved;         // conflitos resolvidos por regra explícita
    std::vector<std::string> conflicts;        // conflitos LL(1) não resolvidos

    static bool isTerminal(int s) { return s < T_COUNT; }
    static std::string name(int sym);
    std::string prodStr(int i) const;
    void printMarkdown(std::ostream& os) const;

private:
    void compute();
    void buildTable();
    std::set<int> firstOfSeq(const std::vector<int>& seq, bool& nullableOut) const;
};
