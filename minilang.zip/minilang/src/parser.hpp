// Parser LL(1) preditivo dirigido por tabela (pilha explícita) com recuperação de erros.
#pragma once
#include <memory>
#include <vector>
#include "grammar.hpp"

struct PNode {
    int sym = 0;    // terminal (Tok) ou não-terminal (NT)
    int prod = -1;  // produção aplicada (não-terminais)
    Token tok;      // token casado (terminais)
    std::vector<std::unique_ptr<PNode>> ch;
};

struct ParseResult {
    std::unique_ptr<PNode> root;  // árvore de derivação (válida só se errors.empty())
    std::vector<Diag> errors;
};

ParseResult parseTokens(const Grammar& g, const std::vector<Token>& toks);
