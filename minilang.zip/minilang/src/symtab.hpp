// Tabela de símbolos inicial (preenchida pelo analisador léxico).
#pragma once
#include <map>
#include <string>
#include <vector>

struct SymInfo {
    std::string name;
    int line, col;  // primeira ocorrência
    int count;      // número de ocorrências
};

class SymbolTable {
public:
    void touch(const std::string& n, int line, int col) {
        auto it = idx_.find(n);
        if (it == idx_.end()) {
            idx_[n] = syms_.size();
            syms_.push_back({n, line, col, 1});
        } else {
            syms_[it->second].count++;
        }
    }
    // Remove uma ocorrência (usado para o nome do programa, que não é variável).
    void release(const std::string& n) {
        auto it = idx_.find(n);
        if (it != idx_.end() && syms_[it->second].count > 0) syms_[it->second].count--;
    }
    const std::vector<SymInfo>& all() const { return syms_; }

private:
    std::vector<SymInfo> syms_;
    std::map<std::string, size_t> idx_;
};
