// AST da MiniLang e construção a partir da árvore de derivação LL(1).
#pragma once
#include <iosfwd>
#include <memory>
#include <string>
#include <vector>
#include "parser.hpp"

enum class NK { Program, Block, Assign, Read, Write, If, While, BinOp, RelOp, Id, Number };

struct Node;
using NodePtr = std::unique_ptr<Node>;

// Convenções dos filhos:
//  Program: text=nome, kids[0]=Block      Block: kids=comandos
//  Assign: text=id, kids[0]=expr          Read: text=id        Write: kids[0]=expr
//  If: kids[0]=RelOp, kids[1]=Block, kids[2]=Block (opcional)   While: kids[0]=RelOp, kids[1]=Block
//  BinOp/RelOp: text=operador, kids[0], kids[1]   Id: text   Number: value
struct Node {
    NK kind;
    std::string text;
    long value = 0;
    int line = 0, col = 0;
    std::vector<NodePtr> kids;
};

NodePtr buildAst(const PNode& parseTree, SymbolTable& st);
void dumpAst(const Node& n, std::ostream& os, int depth = 0);
