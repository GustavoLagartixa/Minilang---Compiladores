#include "grammar.hpp"
#include <iostream>
#include <utility>

namespace {
const char* kNtNames[NUM_NT] = {
    "<programa>", "<bloco>", "<linhas>", "<linhas'>", "<comando>", "<comando_ne>", "<corpo>",
    "<condicional'>", "<relacional>", "<expr>", "<expr'>", "<expr_simples>", "<expr_simples'>",
    "<termo>", "<fator>", "<relop>"};
}

std::string Grammar::name(int sym) {
    if (sym >= T_COUNT) return kNtNames[sym - T_COUNT];
    if (sym == T_EOF) return "$";
    if (sym == T_ID) return "ID";
    if (sym == T_NUMBER) return "NUMBER";
    return tokQuoted(sym);
}

Grammar::Grammar() {
    auto P = [&](int lhs, std::vector<int> rhs) { prods.push_back({lhs, std::move(rhs)}); };
    // Estrutura
    P(N_PROGRAMA, {T_PROGRAM, T_ID, T_COLON, N_BLOCO, T_DOT});              // 0
    P(N_BLOCO, {T_BEGIN, N_LINHAS, T_END});                                 // 1
    P(N_LINHAS, {N_COMANDO, N_LINHAS_P});                                   // 2
    P(N_LINHAS_P, {T_SEMICOLON, N_COMANDO, N_LINHAS_P});                    // 3
    P(N_LINHAS_P, {});                                                      // 4
    P(N_COMANDO, {N_COMANDO_NE});                                           // 5
    P(N_COMANDO, {});                                                       // 6  comando vazio
    // Comandos
    P(N_COMANDO_NE, {T_ID, T_ASSIGN, N_EXPR});                              // 7
    P(N_COMANDO_NE, {T_READ, T_LPAREN, T_ID, T_RPAREN});                    // 8
    P(N_COMANDO_NE, {T_WRITE, T_LPAREN, N_EXPR, T_RPAREN});                 // 9
    P(N_COMANDO_NE, {T_IF, N_RELACIONAL, T_THEN, N_CORPO, N_COND_P});       // 10
    P(N_COMANDO_NE, {T_WHILE, N_RELACIONAL, T_DO, N_CORPO});                // 11
    P(N_CORPO, {N_BLOCO});                                                  // 12
    P(N_CORPO, {N_COMANDO_NE});                                             // 13 extensão (ex. 5.2)
    P(N_COND_P, {T_ELSE, N_CORPO});                                         // 14
    P(N_COND_P, {});                                                        // 15
    // Relacional
    P(N_RELACIONAL, {N_EXPR, N_RELOP, N_EXPR});                             // 16
    // Expressões (sem recursão à esquerda)
    P(N_EXPR, {N_EXPR_S, N_EXPR_P});                                        // 17
    P(N_EXPR_P, {T_PLUS, N_EXPR});                                          // 18
    P(N_EXPR_P, {T_MINUS, N_EXPR});                                         // 19
    P(N_EXPR_P, {});                                                        // 20
    P(N_EXPR_S, {N_TERMO, N_EXPR_S_P});                                     // 21
    P(N_EXPR_S_P, {T_TIMES, N_EXPR_S});                                     // 22
    P(N_EXPR_S_P, {T_DIVIDE, N_EXPR_S});                                    // 23
    P(N_EXPR_S_P, {});                                                      // 24
    P(N_TERMO, {N_FATOR});                                                  // 25
    P(N_TERMO, {T_LPAREN, N_EXPR, T_RPAREN});                               // 26
    P(N_FATOR, {T_ID});                                                     // 27
    P(N_FATOR, {T_NUMBER});                                                 // 28
    P(N_RELOP, {T_EQ});                                                     // 29
    P(N_RELOP, {T_LT});                                                     // 30
    P(N_RELOP, {T_GT});                                                     // 31
    compute();
    buildTable();
}

std::set<int> Grammar::firstOfSeq(const std::vector<int>& seq, bool& nullableOut) const {
    std::set<int> r;
    nullableOut = true;
    for (int s : seq) {
        if (isTerminal(s)) { r.insert(s); nullableOut = false; break; }
        r.insert(first[s - T_COUNT].begin(), first[s - T_COUNT].end());
        if (!nullable[s - T_COUNT]) { nullableOut = false; break; }
    }
    return r;
}

void Grammar::compute() {
    nullable.assign(NUM_NT, false);
    first.assign(NUM_NT, {});
    follow.assign(NUM_NT, {});
    for (bool ch = true; ch;) {
        ch = false;
        for (auto& p : prods) {
            int a = p.lhs - T_COUNT;
            bool nl;
            auto f = firstOfSeq(p.rhs, nl);
            if (nl && !nullable[a]) { nullable[a] = true; ch = true; }
            for (int t : f) if (first[a].insert(t).second) ch = true;
        }
    }
    follow[N_PROGRAMA - T_COUNT].insert(T_EOF);
    for (bool ch = true; ch;) {
        ch = false;
        for (auto& p : prods) {
            for (size_t i = 0; i < p.rhs.size(); i++) {
                int x = p.rhs[i];
                if (isTerminal(x)) continue;
                std::vector<int> rest(p.rhs.begin() + i + 1, p.rhs.end());
                bool nl;
                auto f = firstOfSeq(rest, nl);
                auto& fx = follow[x - T_COUNT];
                for (int t : f) if (fx.insert(t).second) ch = true;
                if (nl)
                    for (int t : follow[p.lhs - T_COUNT]) if (fx.insert(t).second) ch = true;
            }
        }
    }
}

void Grammar::buildTable() {
    table.assign(NUM_NT, std::vector<int>(T_COUNT, -1));
    auto put = [&](int nt, int t, int p) {
        int& cell = table[nt - T_COUNT][t];
        if (cell < 0 || cell == p) { cell = p; return; }
        bool oldEps = prods[cell].rhs.empty(), newEps = prods[p].rhs.empty();
        std::string msg = name(nt) + " x " + name(t) + ": P" + std::to_string(cell) + " vs P" + std::to_string(p);
        if (oldEps != newEps && nt == N_COND_P && t == T_ELSE) {
            // Ambiguidade clássica do "else pendente": o else casa com o if mais próximo.
            if (oldEps) cell = p;
            resolved.push_back(msg + " (else pendente: escolhida a produção com 'else')");
        } else {
            conflicts.push_back(msg);
        }
    };
    for (size_t i = 0; i < prods.size(); i++) {
        bool nl;
        auto f = firstOfSeq(prods[i].rhs, nl);
        for (int t : f) put(prods[i].lhs, t, (int)i);
        if (nl)
            for (int t : follow[prods[i].lhs - T_COUNT]) put(prods[i].lhs, t, (int)i);
    }
}

std::string Grammar::prodStr(int i) const {
    std::string s = name(prods[i].lhs) + " -> ";
    if (prods[i].rhs.empty()) return s + "ε";
    for (size_t k = 0; k < prods[i].rhs.size(); k++) s += (k ? " " : "") + name(prods[i].rhs[k]);
    return s;
}

void Grammar::printMarkdown(std::ostream& os) const {
    os << "<!-- Gerado por `./mlc --grammar`. Não edite à mão. -->\n\n";
    os << "# Gramática LL(1) da MiniLang\n\n## Produções\n\n";
    for (size_t i = 0; i < prods.size(); i++) os << "- P" << i << ": `" << prodStr((int)i) << "`\n";

    auto setStr = [&](const std::set<int>& s, bool eps) {
        std::string r;
        for (int t : s) r += (r.empty() ? "" : ", ") + name(t);
        if (eps) r += (r.empty() ? "" : ", ") + std::string("ε");
        return r;
    };
    os << "\n## FIRST\n\n| Não-terminal | FIRST |\n|---|---|\n";
    for (int n = 0; n < NUM_NT; n++)
        os << "| `" << name(n + T_COUNT) << "` | " << setStr(first[n], nullable[n]) << " |\n";
    os << "\n## FOLLOW\n\n| Não-terminal | FOLLOW |\n|---|---|\n";
    for (int n = 0; n < NUM_NT; n++)
        os << "| `" << name(n + T_COUNT) << "` | " << setStr(follow[n], false) << " |\n";

    std::vector<int> cols;
    for (int t = 0; t < T_COUNT; t++) {
        bool used = (t == T_EOF);
        for (auto& p : prods) for (int s : p.rhs) if (s == t) used = true;
        if (used) cols.push_back(t);
    }
    os << "\n## Tabela LL(1)\n\nCada célula traz o número da produção Pn a aplicar; célula vazia = erro sintático.\n\n| |";
    for (int t : cols) os << " " << name(t) << " |";
    os << "\n|---|";
    for (size_t k = 0; k < cols.size(); k++) os << "---|";
    os << "\n";
    for (int n = 0; n < NUM_NT; n++) {
        os << "| `" << name(n + T_COUNT) << "` |";
        for (int t : cols) {
            int p = table[n][t];
            os << " " << (p < 0 ? "" : "P" + std::to_string(p)) << " |";
        }
        os << "\n";
    }
    os << "\n## Conflitos\n\n";
    if (conflicts.empty()) os << "Nenhum conflito LL(1) não resolvido: a gramática é LL(1) com a regra abaixo.\n";
    for (auto& c : conflicts) os << "- **CONFLITO**: " << c << "\n";
    for (auto& c : resolved) os << "- Resolvido: " << c << "\n";
}
