#include "lexer.hpp"
#include <map>

namespace {
const char* kNames[T_COUNT] = {
    "PROGRAM", "BEGIN", "END", "READ", "WRITE", "IF", "THEN", "ELSE", "WHILE", "DO", "INT",
    "ID", "NUMBER", "ASSIGN", "PLUS", "MINUS", "TIMES", "DIVIDE", "EQ", "LT", "GT",
    "LPAREN", "RPAREN", "LBRACE", "RBRACE", "SEMICOLON", "COLON", "COMMA", "DOT", "EOF"};

const char* kTexts[T_COUNT] = {
    "'program'", "'begin'", "'end'", "'read'", "'write'", "'if'", "'then'", "'else'", "'while'",
    "'do'", "'int'", "identificador", "número", "'='", "'+'", "'-'", "'*'", "'/'", "'=='", "'<'",
    "'>'", "'('", "')'", "'{'", "'}'", "';'", "':'", "','", "'.'", "fim do arquivo"};

inline bool isLow(char c) { return c >= 'a' && c <= 'z'; }
inline bool isUp(char c) { return c >= 'A' && c <= 'Z'; }
inline bool isDig(char c) { return c >= '0' && c <= '9'; }
constexpr long long kMaxInt = 2147483647LL;  // 2^31 - 1
}  // namespace

const char* tokName(int k) { return kNames[k]; }
std::string tokQuoted(int k) { return kTexts[k]; }

std::string describe(const Token& t) {
    if (t.kind == T_ID) return "identificador '" + t.lexeme + "'";
    if (t.kind == T_NUMBER) return "número " + t.lexeme;
    return kTexts[t.kind];
}

std::vector<Token> lex(const std::string& s, SymbolTable& st, std::vector<Diag>& errs) {
    static const std::map<std::string, int> kw = {
        {"program", T_PROGRAM}, {"begin", T_BEGIN}, {"end", T_END},   {"read", T_READ},
        {"write", T_WRITE},     {"if", T_IF},       {"then", T_THEN}, {"else", T_ELSE},
        {"while", T_WHILE},     {"do", T_DO},       {"int", T_INT}};

    std::vector<Token> out;
    size_t i = 0;
    int line = 1, col = 1;
    auto adv = [&]() {
        if (s[i] == '\n') { line++; col = 1; } else { col++; }
        i++;
    };
    auto err = [&](int l, int c, const std::string& m) { errs.push_back({l, c, true, m}); };

    while (i < s.size()) {
        char c = s[i];
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') { adv(); continue; }
        if (c == '/' && i + 1 < s.size() && s[i + 1] == '/') {  // comentário
            while (i < s.size() && s[i] != '\n') adv();
            continue;
        }

        Token t;
        t.line = line; t.col = col;

        // identificadores e palavras reservadas: [a-z][a-z0-9_]*
        if (isLow(c) || isUp(c)) {
            bool upper = false;
            while (i < s.size() && (isLow(s[i]) || isUp(s[i]) || isDig(s[i]) || s[i] == '_')) {
                if (isUp(s[i])) upper = true;
                t.lexeme += s[i];
                adv();
            }
            if (upper)
                err(t.line, t.col, "'" + t.lexeme + "' contém letra maiúscula (a linguagem só aceita minúsculas)");
            auto it = kw.find(t.lexeme);
            if (it != kw.end()) {
                t.kind = it->second;
            } else {
                t.kind = T_ID;
                st.touch(t.lexeme, t.line, t.col);
            }
            out.push_back(t);
            continue;
        }

        // números: [0-9]+
        if (isDig(c)) {
            bool overflow = false;
            long long v = 0;
            while (i < s.size() && isDig(s[i])) {
                t.lexeme += s[i];
                if (!overflow) {
                    v = v * 10 + (s[i] - '0');
                    if (v > kMaxInt) overflow = true;
                }
                adv();
            }
            if (i < s.size() && (isLow(s[i]) || isUp(s[i]) || s[i] == '_')) {
                while (i < s.size() && (isLow(s[i]) || isUp(s[i]) || isDig(s[i]) || s[i] == '_')) {
                    t.lexeme += s[i];
                    adv();
                }
                err(t.line, t.col, "identificador não pode começar com dígito: '" + t.lexeme + "'");
                t.kind = T_ID;  // evita erros em cascata no parser
                out.push_back(t);
                continue;
            }
            if (overflow) err(t.line, t.col, "número " + t.lexeme + " fora do intervalo (0 a 2147483647)");
            t.kind = T_NUMBER;
            t.value = overflow ? 0 : v;
            out.push_back(t);
            continue;
        }

        // operadores e delimitadores
        auto single = [&](int kind) { t.kind = kind; t.lexeme = std::string(1, c); adv(); };
        switch (c) {
            case '=':
                adv();
                if (i < s.size() && s[i] == '=') { adv(); t.kind = T_EQ; t.lexeme = "=="; }
                else { t.kind = T_ASSIGN; t.lexeme = "="; }
                break;
            case '+': single(T_PLUS); break;
            case '-': single(T_MINUS); break;
            case '*': single(T_TIMES); break;
            case '/': single(T_DIVIDE); break;
            case '<': single(T_LT); break;
            case '>': single(T_GT); break;
            case '(': single(T_LPAREN); break;
            case ')': single(T_RPAREN); break;
            case '{': single(T_LBRACE); break;
            case '}': single(T_RBRACE); break;
            case ';': single(T_SEMICOLON); break;
            case ':': single(T_COLON); break;
            case ',': single(T_COMMA); break;
            case '.': single(T_DOT); break;
            default:
                if (static_cast<unsigned char>(c) >= 0x80) {
                    while (i < s.size() && static_cast<unsigned char>(s[i]) >= 0x80) adv();
                    err(t.line, t.col, "caractere não-ASCII inválido");
                } else {
                    err(t.line, t.col, std::string("caractere inválido '") + c + "'");
                    adv();
                }
                continue;
        }
        out.push_back(t);
    }
    Token e;
    e.kind = T_EOF; e.line = line; e.col = col;
    out.push_back(e);
    return out;
}
