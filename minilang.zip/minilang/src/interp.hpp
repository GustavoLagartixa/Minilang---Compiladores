#pragma once
#include <cstdint>
#include <iosfwd>
#include <string>
#include <vector>
#include "ast.hpp"

struct RunResult {
    bool ok = true;
    std::string error;
    int line = 0, col = 0;
};

// Executa o programa. `input` é a fila de inteiros lida por read(); write() imprime em `out`.
RunResult interpret(const Node& program, const std::vector<int64_t>& input, std::ostream& out,
                    int64_t maxSteps = 50000000);
