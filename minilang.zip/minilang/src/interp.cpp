#include "interp.hpp"
#include <deque>
#include <map>
#include <ostream>

namespace {
constexpr int64_t kMaxInt = 2147483647;

struct RuntimeError { int line, col; std::string msg; };

struct Ctx {
    std::map<std::string, int64_t> mem;  // variáveis não inicializadas valem 0
    std::deque<int64_t> in;
    std::ostream& out;
    int64_t steps = 0, maxSteps;
    Ctx(std::ostream& o, int64_t m) : out(o), maxSteps(m) {}
};

int64_t eval(const Node& n, Ctx& c) {
    switch (n.kind) {
        case NK::Number: return n.value;
        case NK::Id: {
            auto it = c.mem.find(n.text);
            return it == c.mem.end() ? 0 : it->second;
        }
        default: break;
    }
    int64_t a = eval(*n.kids[0], c), b = eval(*n.kids[1], c), v = 0;
    switch (n.text[0]) {
        case '+': v = a + b; break;
        case '-': v = a - b; break;
        case '*': v = a * b; break;
        default:
            if (b == 0) throw RuntimeError{n.line, n.col, "divisão por zero"};
            v = a / b;
    }
    if (v < 0) throw RuntimeError{n.line, n.col, "resultado negativo (" + std::to_string(v) + "): a MiniLang só tem inteiros não negativos"};
    if (v > kMaxInt) throw RuntimeError{n.line, n.col, "estouro: resultado maior que 2^31-1"};
    return v;
}

bool cond(const Node& n, Ctx& c) {
    int64_t a = eval(*n.kids[0], c), b = eval(*n.kids[1], c);
    if (n.text == "==") return a == b;
    if (n.text == "<") return a < b;
    return a > b;
}

void exec(const Node& n, Ctx& c) {
    if (++c.steps > c.maxSteps)
        throw RuntimeError{n.line, n.col, "limite de passos excedido (possível laço infinito)"};
    switch (n.kind) {
        case NK::Block:
            for (auto& k : n.kids) exec(*k, c);
            break;
        case NK::Assign: c.mem[n.text] = eval(*n.kids[0], c); break;
        case NK::Read:
            if (c.in.empty()) throw RuntimeError{n.line, n.col, "entrada esgotada em read(" + n.text + ")"};
            c.mem[n.text] = c.in.front();
            c.in.pop_front();
            break;
        case NK::Write: c.out << eval(*n.kids[0], c) << "\n"; break;
        case NK::If:
            if (cond(*n.kids[0], c)) exec(*n.kids[1], c);
            else if (n.kids.size() > 2) exec(*n.kids[2], c);
            break;
        case NK::While:
            while (cond(*n.kids[0], c)) {
                exec(*n.kids[1], c);
                if (++c.steps > c.maxSteps)
                    throw RuntimeError{n.line, n.col, "limite de passos excedido (possível laço infinito)"};
            }
            break;
        default: break;
    }
}
}  // namespace

RunResult interpret(const Node& program, const std::vector<int64_t>& input, std::ostream& out,
                    int64_t maxSteps) {
    Ctx c(out, maxSteps);
    c.in.assign(input.begin(), input.end());
    RunResult r;
    try {
        exec(*program.kids[0], c);
    } catch (const RuntimeError& e) {
        r.ok = false; r.error = e.msg; r.line = e.line; r.col = e.col;
    }
    return r;
}
