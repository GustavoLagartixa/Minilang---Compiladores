// MiniComp: front-end da MiniLang (léxico + sintático LL(1) + AST + interpretador).
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include "ast.hpp"
#include "grammar.hpp"
#include "interp.hpp"
#include "lexer.hpp"
#include "parser.hpp"

static void usage() {
    std::cerr <<
        "uso: mlc [opções] arquivo.ml\n"
        "  --tokens    lista os tokens reconhecidos\n"
        "  --symbols   mostra a tabela de símbolos\n"
        "  --ast       imprime a árvore sintática abstrata\n"
        "  --run       executa o programa (lê os inteiros de entrada da stdin)\n"
        "  --grammar   imprime produções, FIRST, FOLLOW e tabela LL(1) (sem arquivo)\n"
        "saída: 0 = ok, 1 = erro léxico/sintático, 2 = erro de execução, 3 = uso/arquivo\n";
}

int main(int argc, char** argv) {
    bool optTokens = false, optSymbols = false, optAst = false, optRun = false, optGrammar = false;
    std::string path;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--tokens") optTokens = true;
        else if (a == "--symbols") optSymbols = true;
        else if (a == "--ast") optAst = true;
        else if (a == "--run") optRun = true;
        else if (a == "--grammar") optGrammar = true;
        else if (a == "-h" || a == "--help") { usage(); return 0; }
        else if (!a.empty() && a[0] == '-') { std::cerr << "opção desconhecida: " << a << "\n"; usage(); return 3; }
        else path = a;
    }

    Grammar g;
    if (optGrammar) {
        g.printMarkdown(std::cout);
        return g.conflicts.empty() ? 0 : 1;
    }
    if (path.empty()) { usage(); return 3; }

    std::ifstream f(path, std::ios::binary);
    if (!f) { std::cerr << "não foi possível abrir '" << path << "'\n"; return 3; }
    std::stringstream buf;
    buf << f.rdbuf();

    SymbolTable st;
    std::vector<Diag> diags;
    auto toks = lex(buf.str(), st, diags);

    if (optTokens)
        for (auto& t : toks) std::cout << t.line << ":" << t.col << "\t" << tokName(t.kind) << "\t" << t.lexeme << "\n";

    auto pr = parseTokens(g, toks);
    diags.insert(diags.end(), pr.errors.begin(), pr.errors.end());

    if (!diags.empty()) {
        std::stable_sort(diags.begin(), diags.end(), [](const Diag& a, const Diag& b) {
            return a.line != b.line ? a.line < b.line : a.col < b.col;
        });
        for (auto& d : diags)
            std::cerr << path << ":" << d.line << ":" << d.col << ": erro "
                      << (d.lexical ? "léxico" : "sintático") << ": " << d.msg << "\n";
        std::cerr << diags.size() << " erro(s); AST não gerada.\n";
        return 1;
    }

    NodePtr ast = buildAst(*pr.root, st);

    if (optSymbols) {
        std::cout << "nome\t1a ocorrência\tusos\n";
        for (auto& s : st.all())
            if (s.count > 0) std::cout << s.name << "\t" << s.line << ":" << s.col << "\t" << s.count << "\n";
    }
    if (optAst) dumpAst(*ast, std::cout);

    if (optRun) {
        std::vector<int64_t> input;
        std::string w;
        while (std::cin >> w) {
            char* end = nullptr;
            long long v = std::strtoll(w.c_str(), &end, 10);
            if (*end != '\0' || v < 0) {
                std::cerr << "entrada inválida: '" << w << "' (esperado inteiro não negativo)\n";
                return 2;
            }
            input.push_back(v);
        }
        RunResult rr = interpret(*ast, input, std::cout);
        if (!rr.ok) {
            std::cout.flush();
            std::cerr << path << ":" << rr.line << ":" << rr.col << ": erro de execução: " << rr.error << "\n";
            return 2;
        }
    } else if (!optTokens && !optSymbols && !optAst) {
        std::cout << "OK: " << path << " é um programa MiniLang válido.\n";
    }
    return 0;
}
