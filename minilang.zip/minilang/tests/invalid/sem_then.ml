program p:
begin
  if 1 < 2 write(1)
end.
