program lex:
begin
  x = 5 @ 3;
  Y = 99999999999;
  z = 3abc
end.
