program p:
begin
  write(1)
end. write(2)
