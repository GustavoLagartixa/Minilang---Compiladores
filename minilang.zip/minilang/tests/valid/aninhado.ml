program aninhado:
begin
  read(n); i = 1;
  while i < n + 1 do begin
    if i / 2 * 2 == i then
      begin write(i) end
    else begin
      if i == 3 then write(333) else write(0)
    end;
    i = i + 1
  end;
  ;;
end.
