program vazio:
begin
end.
