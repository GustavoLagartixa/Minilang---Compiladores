program pendente:
begin
  a = 1; b = 2;
  if a == 1 then if b == 5 then write(1) else write(2)
end.
