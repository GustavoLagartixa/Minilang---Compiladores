program maximo:
begin
  read(a);
  read(b);
  if a > b then
    write(a)
  else
    write(b)
end.
