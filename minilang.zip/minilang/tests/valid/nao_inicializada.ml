program zero:
begin
  write(x + 7)   // variáveis não inicializadas valem 0
end.
