program assoc: // a gramática LL(1) é recursiva à direita; a AST deve ser à esquerda
begin
  write(10 - 3 - 2);      // (10-3)-2 = 5
  write(8 / 2 * 2);       // (8/2)*2 = 8
  write(2 + 3 * 4);       // 14
  write((2 + 3) * 4);     // 20
  write(100 - 10 + 5 - 1) // 94
end.
