program d:
begin
  read(a);
  write(10 / a)
end.
