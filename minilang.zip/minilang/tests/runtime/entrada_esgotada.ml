program e:
begin
  read(a)
end.
