program n:
begin
  a = 3;
  write(a - 5)
end.
