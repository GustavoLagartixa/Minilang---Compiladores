program inf:
begin
  x = 1;
  while x > 0 do x = x + 0
end.
