#!/bin/sh
# Executa os testes: valid/ (saída esperada), invalid/ (exit 1) e runtime/ (exit 2).
cd "$(dirname "$0")/.." || exit 1
pass=0; fail=0
ok()  { pass=$((pass+1)); echo "  ok   $1"; }
bad() { fail=$((fail+1)); echo "  FAIL $1 ($2)"; }

for f in tests/valid/*.ml; do
  b=${f%.ml}; in=/dev/null; [ -f "$b.in" ] && in="$b.in"
  got=$(./mlc --run "$f" < "$in" 2>&1)
  if [ "$got" = "$(cat "$b.out")" ]; then ok "$f"; else bad "$f" "saída diferente"; fi
done
for f in tests/invalid/*.ml; do
  b=${f%.ml}
  err=$(./mlc "$f" 2>&1 >/dev/null); code=$?
  if [ $code -ne 1 ]; then bad "$f" "exit=$code, esperado 1"
  elif ! echo "$err" | grep -qF -- "$(cat "$b.expect")"; then bad "$f" "mensagem sem '$(cat "$b.expect")'"
  else ok "$f"; fi
done
for f in tests/runtime/*.ml; do
  b=${f%.ml}; in=/dev/null; [ -f "$b.in" ] && in="$b.in"
  err=$(./mlc --run "$f" < "$in" 2>&1 >/dev/null); code=$?
  if [ $code -ne 2 ]; then bad "$f" "exit=$code, esperado 2"
  elif ! echo "$err" | grep -qF -- "$(cat "$b.expect")"; then bad "$f" "mensagem sem '$(cat "$b.expect")'"
  else ok "$f"; fi
done
echo "passaram: $pass, falharam: $fail"
[ $fail -eq 0 ]
