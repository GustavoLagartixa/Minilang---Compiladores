# MiniComp: front-end LL(1) da MiniLang

Analisador léxico, parser LL(1) **preditivo dirigido por tabela (pilha explícita)**, AST e
interpretador, em C++17. Sem dependências externas.

## Uso

```
make                       # gera ./mlc
./mlc prog.ml              # só valida (léxico + sintático)
./mlc --tokens prog.ml     # lista de tokens com linha:coluna
./mlc --symbols prog.ml    # tabela de símbolos
./mlc --ast prog.ml        # árvore sintática abstrata
echo 5 | ./mlc --run tests/valid/fatorial.ml     # executa (entrada pela stdin)
./mlc --grammar            # produções, FIRST, FOLLOW e tabela LL(1)
make test                  # 17 casos: válidos, inválidos e erros de execução
make docs                  # regenera docs/grammar.md e jflap/*.jff
```
Códigos de saída: 0 ok · 1 erro léxico/sintático · 2 erro de execução · 3 uso.

## Estrutura

| Pasta/arquivo | Conteúdo |
|---|---|
| `src/lexer.*` | scanner: tokens, comentários `//`, espaços, erros léxicos com posição |
| `src/grammar.*` | produções LL(1), cálculo de FIRST/FOLLOW e da tabela (detecta conflitos) |
| `src/parser.*` | parser com pilha, árvore de derivação e recuperação de erros (modo pânico) |
| `src/ast.*` | AST + construção a partir da árvore de derivação |
| `src/interp.*` | interpretador semântico |
| `docs/grammar.md` | FIRST/FOLLOW/tabela LL(1), **gerado** a partir do código |
| `jflap/*.jff` | AFDs dos tokens (id, number, keywords, relops, symbols, assign_eq, comment), gerados por `tools/gen_jflap.py`. WHITESPACE não tem arquivo e o comentário não cobre espaço nem `[`: o JFLAP 7.1 lê espaço/tab como λ e dá erro interno com `[` |
| `tests/` | `valid/` (com `.in`/`.out`), `invalid/` e `runtime/` (com `.expect`) |

## Decisões de projeto (pontos em que a especificação é inconsistente)

1. **Corpo de `then`/`else`/`do` sem `begin/end`.** A regra 6.1.4 exige blocos, mas o exemplo 5.2
   (`maximo`) usa `then write(a) else write(b)`. O parser aceita as duas formas
   (`<corpo> → <bloco> | <comando_ne>`).
2. **Else pendente.** A extensão acima cria o conflito clássico em `<condicional'>` × `else`. Resolvido
   casando o `else` com o `if` mais próximo (documentado em `docs/grammar.md`).
3. **`_` em identificadores.** O exemplo 5.3 usa `soma_ate_zero`, então ID = `[a-z][a-z0-9_]*`.
4. **Associatividade.** A gramática (recursiva à direita) faz `10-3-2` parecer `10-(3-2)`. A AST é
   refeita com associatividade à esquerda: `10-3-2 = 5` e `8/2*2 = 8` (ver `tests/valid/associatividade.ml`).
5. **Comando vazio e `;`.** `<linhas> → <comando> (';' <comando>)*` com comando vazio permitido:
   cobre "o último comando do bloco não leva `;`" e `begin end`.
6. **Variáveis.** Tabela por nome (não só `a-z`), pois os exemplos usam `fat`, `soma`, `valor`.
   Não inicializadas valem 0 (6.2.1).
7. **Faixa de valores.** 0 a 2³¹−1. Resultado negativo ou estouro, divisão por zero, `read` sem
   entrada e laço sem fim (50 milhões de passos) são **erros de execução** com linha:coluna.
8. `int`, `{`, `}` e `,` são tokens reconhecidos, mas não fazem parte da gramática: aparecem como erro sintático.

## Recuperação de erros

Após um erro, descarta tokens até `;`, `end`, `.` ou fim de arquivo, desempilha até o topo
conseguir tratar o token atual e continua (até 30 erros). Erro léxico ou sintático impede a AST.
