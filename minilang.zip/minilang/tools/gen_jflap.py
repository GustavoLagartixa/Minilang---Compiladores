#!/usr/bin/env python3
"""Gera os autômatos dos tokens da MiniLang no formato .jff do JFLAP (jflap/*.jff).

Cada autômato é um AFD definido como dados Python; antes de gravar, o script o simula com
exemplos que devem ser aceitos/rejeitados (assim os arquivos nunca ficam fora de sincronia
com o lexer). Para abrir: JFLAP > File > Open, depois Input > Multiple Run para testar.
"""
import os, string
from xml.sax.saxutils import escape

LOW = list(string.ascii_lowercase)
DIG = list(string.digits)


class DFA:
    def __init__(self, name):
        self.name, self.states, self.finals, self.edges = name, [], set(), {}
        self.order = []

    def state(self, s, final=False):
        if s not in self.states:
            self.states.append(s)
        if final:
            self.finals.add(s)

    def edge(self, a, chars, b):
        for c in chars:
            self.edges[(a, c)] = b

    def accepts(self, w):
        s = self.states[0]
        for c in w:
            s = self.edges.get((s, c))
            if s is None:
                return False
        return s in self.finals

    def write(self, path):
        out = ['<?xml version="1.0" encoding="UTF-8" standalone="no"?>',
               '<structure>', '\t<type>fa</type>', '\t<automaton>']
        for i, s in enumerate(self.states):
            x = 80 + 130 * (i % 8)
            y = 80 + 110 * (i // 8)
            out.append(f'\t\t<state id="{i}" name="{escape(s)}">')
            out.append(f'\t\t\t<x>{x}.0</x>\n\t\t\t<y>{y}.0</y>')
            if i == 0:
                out.append('\t\t\t<initial/>')
            if s in self.finals:
                out.append('\t\t\t<final/>')
            out.append('\t\t</state>')
        ids = {s: i for i, s in enumerate(self.states)}
        for (a, c), b in sorted(self.edges.items(), key=lambda kv: (ids[kv[0][0]], ids[kv[1]], kv[0][1])):
            out.append(f'\t\t<transition>\n\t\t\t<from>{ids[a]}</from>\n\t\t\t<to>{ids[b]}</to>\n'
                       f'\t\t\t<read>{escape(c)}</read>\n\t\t</transition>')
        out += ['\t</automaton>', '</structure>', '']
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(out))


def make_id():            # ID = [a-z][a-z0-9_]*
    d = DFA('id'); d.state('q0'); d.state('q1', True)
    d.edge('q0', LOW, 'q1'); d.edge('q1', LOW + DIG + ['_'], 'q1')
    return d, ['x', 'contador', 'var1', 'soma_ate_zero'], ['', '1a', 'X', '_a', 'a-b']

def make_number():        # NUMBER = [0-9]+
    d = DFA('number'); d.state('q0'); d.state('q1', True)
    d.edge('q0', DIG, 'q1'); d.edge('q1', DIG, 'q1')
    return d, ['0', '42', '100'], ['', 'a', '4a', '-1']

def make_assign_eq():     # ASSIGN '=' | EQ '=='
    d = DFA('assign_eq'); d.state('q0'); d.state('q1', True); d.state('q2', True)
    d.edge('q0', ['='], 'q1'); d.edge('q1', ['='], 'q2')
    return d, ['=', '=='], ['', '===', '<']

def make_relops():        # LT '<' | GT '>' | EQ '=='
    d = DFA('relops'); d.state('q0'); d.state('lt', True); d.state('gt', True)
    d.state('eq1'); d.state('eq', True)
    d.edge('q0', ['<'], 'lt'); d.edge('q0', ['>'], 'gt'); d.edge('q0', ['='], 'eq1'); d.edge('eq1', ['='], 'eq')
    return d, ['<', '>', '=='], ['=', '<>', '']

def make_symbols():       # + - * / ( ) { } ; : , .
    d = DFA('symbols'); d.state('q0')
    names = {'+': 'plus', '-': 'minus', '*': 'times', '/': 'divide', '(': 'lparen', ')': 'rparen',
             '{': 'lbrace', '}': 'rbrace', ';': 'semicolon', ':': 'colon', ',': 'comma', '.': 'dot'}
    for ch, n in names.items():
        d.state(n, True); d.edge('q0', [ch], n)
    return d, list(names), ['', '++', 'a']

def make_comment():       # COMMENT = //[^\n]*
    d = DFA('comment'); d.state('q0'); d.state('s1'); d.state('c', True)
    # ASCII imprimível sem espaço (no JFLAP, espaço vira lambda) e sem '[' (o JFLAP 7.1 dá erro interno com ele)
    printable = [chr(c) for c in range(33, 127) if chr(c) != '[']
    d.edge('q0', ['/'], 's1'); d.edge('s1', ['/'], 'c'); d.edge('c', printable, 'c')
    return d, ['//', '//comentario', '//x=1;'], ['/', '/ /', 'a']

def make_whitespace():    # WHITESPACE = [ \t\n]+ (no JFLAP: espaço e tab; '\n' omitido)
    d = DFA('whitespace'); d.state('q0'); d.state('q1', True)
    d.edge('q0', [' ', '\t'], 'q1'); d.edge('q1', [' ', '\t'], 'q1')  # \n não pode ser digitado no JFLAP
    return d, [' ', '\t ', '   '], ['', 'a', ' a', '\n']

KEYWORDS = ['program', 'begin', 'end', 'read', 'write', 'if', 'then', 'else', 'while', 'do', 'int']

def make_keywords():      # trie das palavras reservadas (cada estado final = um token)
    d = DFA('keywords'); d.state('q0')
    for kw in KEYWORDS:
        prev = 'q0'
        for i in range(1, len(kw) + 1):
            s = kw[:i]
            d.state(s, final=(i == len(kw)))
            d.edge(prev, [kw[i - 1]], s)
            prev = s
    return d, KEYWORDS, ['', 'prog', 'programa', 'While', 'x']


for maker in [make_id, make_number, make_assign_eq, make_relops, make_symbols, make_comment,
              make_keywords]:
    d, good, bad = maker()
    for w in good:
        assert d.accepts(w), f'{d.name} deveria aceitar {w!r}'
    for w in bad:
        assert not d.accepts(w), f'{d.name} deveria rejeitar {w!r}'
    path = os.path.join(os.path.dirname(__file__), '..', 'jflap', d.name + '.jff')
    d.write(path)
    print('gerado', os.path.normpath(path), f'({len(d.states)} estados)')
