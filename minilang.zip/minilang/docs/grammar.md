<!-- Gerado por `./mlc --grammar`. Não edite à mão. -->

# Gramática LL(1) da MiniLang

## Produções

- P0: `<programa> -> 'program' ID ':' <bloco> '.'`
- P1: `<bloco> -> 'begin' <linhas> 'end'`
- P2: `<linhas> -> <comando> <linhas'>`
- P3: `<linhas'> -> ';' <comando> <linhas'>`
- P4: `<linhas'> -> ε`
- P5: `<comando> -> <comando_ne>`
- P6: `<comando> -> ε`
- P7: `<comando_ne> -> ID '=' <expr>`
- P8: `<comando_ne> -> 'read' '(' ID ')'`
- P9: `<comando_ne> -> 'write' '(' <expr> ')'`
- P10: `<comando_ne> -> 'if' <relacional> 'then' <corpo> <condicional'>`
- P11: `<comando_ne> -> 'while' <relacional> 'do' <corpo>`
- P12: `<corpo> -> <bloco>`
- P13: `<corpo> -> <comando_ne>`
- P14: `<condicional'> -> 'else' <corpo>`
- P15: `<condicional'> -> ε`
- P16: `<relacional> -> <expr> <relop> <expr>`
- P17: `<expr> -> <expr_simples> <expr'>`
- P18: `<expr'> -> '+' <expr>`
- P19: `<expr'> -> '-' <expr>`
- P20: `<expr'> -> ε`
- P21: `<expr_simples> -> <termo> <expr_simples'>`
- P22: `<expr_simples'> -> '*' <expr_simples>`
- P23: `<expr_simples'> -> '/' <expr_simples>`
- P24: `<expr_simples'> -> ε`
- P25: `<termo> -> <fator>`
- P26: `<termo> -> '(' <expr> ')'`
- P27: `<fator> -> ID`
- P28: `<fator> -> NUMBER`
- P29: `<relop> -> '=='`
- P30: `<relop> -> '<'`
- P31: `<relop> -> '>'`

## FIRST

| Não-terminal | FIRST |
|---|---|
| `<programa>` | 'program' |
| `<bloco>` | 'begin' |
| `<linhas>` | 'read', 'write', 'if', 'while', ID, ';', ε |
| `<linhas'>` | ';', ε |
| `<comando>` | 'read', 'write', 'if', 'while', ID, ε |
| `<comando_ne>` | 'read', 'write', 'if', 'while', ID |
| `<corpo>` | 'begin', 'read', 'write', 'if', 'while', ID |
| `<condicional'>` | 'else', ε |
| `<relacional>` | ID, NUMBER, '(' |
| `<expr>` | ID, NUMBER, '(' |
| `<expr'>` | '+', '-', ε |
| `<expr_simples>` | ID, NUMBER, '(' |
| `<expr_simples'>` | '*', '/', ε |
| `<termo>` | ID, NUMBER, '(' |
| `<fator>` | ID, NUMBER |
| `<relop>` | '==', '<', '>' |

## FOLLOW

| Não-terminal | FOLLOW |
|---|---|
| `<programa>` | $ |
| `<bloco>` | 'end', 'else', ';', '.' |
| `<linhas>` | 'end' |
| `<linhas'>` | 'end' |
| `<comando>` | 'end', ';' |
| `<comando_ne>` | 'end', 'else', ';' |
| `<corpo>` | 'end', 'else', ';' |
| `<condicional'>` | 'end', 'else', ';' |
| `<relacional>` | 'then', 'do' |
| `<expr>` | 'end', 'then', 'else', 'do', '==', '<', '>', ')', ';' |
| `<expr'>` | 'end', 'then', 'else', 'do', '==', '<', '>', ')', ';' |
| `<expr_simples>` | 'end', 'then', 'else', 'do', '+', '-', '==', '<', '>', ')', ';' |
| `<expr_simples'>` | 'end', 'then', 'else', 'do', '+', '-', '==', '<', '>', ')', ';' |
| `<termo>` | 'end', 'then', 'else', 'do', '+', '-', '*', '/', '==', '<', '>', ')', ';' |
| `<fator>` | 'end', 'then', 'else', 'do', '+', '-', '*', '/', '==', '<', '>', ')', ';' |
| `<relop>` | ID, NUMBER, '(' |

## Tabela LL(1)

Cada célula traz o número da produção Pn a aplicar; célula vazia = erro sintático.

| | 'program' | 'begin' | 'end' | 'read' | 'write' | 'if' | 'then' | 'else' | 'while' | 'do' | ID | NUMBER | '=' | '+' | '-' | '*' | '/' | '==' | '<' | '>' | '(' | ')' | ';' | ':' | '.' | $ |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `<programa>` | P0 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `<bloco>` |  | P1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `<linhas>` |  |  | P2 | P2 | P2 | P2 |  |  | P2 |  | P2 |  |  |  |  |  |  |  |  |  |  |  | P2 |  |  |  |
| `<linhas'>` |  |  | P4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | P3 |  |  |  |
| `<comando>` |  |  | P6 | P5 | P5 | P5 |  |  | P5 |  | P5 |  |  |  |  |  |  |  |  |  |  |  | P6 |  |  |  |
| `<comando_ne>` |  |  |  | P8 | P9 | P10 |  |  | P11 |  | P7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `<corpo>` |  | P12 |  | P13 | P13 | P13 |  |  | P13 |  | P13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `<condicional'>` |  |  | P15 |  |  |  |  | P14 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | P15 |  |  |  |
| `<relacional>` |  |  |  |  |  |  |  |  |  |  | P16 | P16 |  |  |  |  |  |  |  |  | P16 |  |  |  |  |  |
| `<expr>` |  |  |  |  |  |  |  |  |  |  | P17 | P17 |  |  |  |  |  |  |  |  | P17 |  |  |  |  |  |
| `<expr'>` |  |  | P20 |  |  |  | P20 | P20 |  | P20 |  |  |  | P18 | P19 |  |  | P20 | P20 | P20 |  | P20 | P20 |  |  |  |
| `<expr_simples>` |  |  |  |  |  |  |  |  |  |  | P21 | P21 |  |  |  |  |  |  |  |  | P21 |  |  |  |  |  |
| `<expr_simples'>` |  |  | P24 |  |  |  | P24 | P24 |  | P24 |  |  |  | P24 | P24 | P22 | P23 | P24 | P24 | P24 |  | P24 | P24 |  |  |  |
| `<termo>` |  |  |  |  |  |  |  |  |  |  | P25 | P25 |  |  |  |  |  |  |  |  | P26 |  |  |  |  |  |
| `<fator>` |  |  |  |  |  |  |  |  |  |  | P27 | P28 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `<relop>` |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | P29 | P30 | P31 |  |  |  |  |  |  |

## Conflitos

Nenhum conflito LL(1) não resolvido: a gramática é LL(1) com a regra abaixo.
- Resolvido: <condicional'> x 'else': P14 vs P15 (else pendente: escolhida a produção com 'else')
